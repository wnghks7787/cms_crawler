<?xml version="1.0" encoding="utf-8"?>
<!-- generator="Joomla! - Open Source Content Management" -->
<feed xmlns="http://www.w3.org/2005/Atom"  xml:lang="en-gb">
	<title type="text">Home</title>
	<subtitle type="text"></subtitle>
	<link rel="alternate" type="text/html" href="http://localhost:10174"/>
	<id>http://localhost:10174/index.php</id>
	<updated>2025-10-29T04:29:53+00:00</updated>
	<generator uri="https://www.joomla.org">Joomla! - Open Source Content Management</generator>
	<link rel="self" type="application/atom+xml" href="http://localhost:10174/index.php?format=feed&amp;type=atom"/>
</feed>
