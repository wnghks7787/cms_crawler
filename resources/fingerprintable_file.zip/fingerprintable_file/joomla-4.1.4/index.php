<?xml version="1.0" encoding="utf-8"?>
<!-- generator="Joomla! - Open Source Content Management" -->
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
	<channel>
		<title>Home</title>
		<description><![CDATA[]]></description>
		<link>http://localhost:10133/index.php</link>
		<lastBuildDate>Wed, 29 Oct 2025 04:25:58 +0000</lastBuildDate>
		<generator>Joomla! - Open Source Content Management</generator>
		<atom:link rel="self" type="application/rss+xml" href="http://localhost:10133/index.php?format=feed&amp;type=rss"/>
		<language>en-gb</language>
	</channel>
</rss>
